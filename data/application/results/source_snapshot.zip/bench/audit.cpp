#include "varblockspmm/vbsr.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cuda_runtime.h>
#include <functional>
#include <iomanip>
#include <iostream>
#include <random>
#include <string>

namespace {
void check(cudaError_t status) {
  if (status != cudaSuccess)
    throw std::runtime_error(cudaGetErrorString(status));
}
struct Buffer {
  float* data{};
  explicit Buffer(size_t count) { check(cudaMalloc(&data, count * sizeof(float))); }
  ~Buffer() { cudaFree(data); }
};

vbsr::HostMatrix thin_rows(const vbsr::HostMatrix& source) {
  auto a = source;
  a.row_ptr = {0};
  a.block_col.clear();
  a.values.clear();
  a.value_off = {0};
  for (int r = 0; r < source.block_rows; ++r) {
    int count = source.row_ptr[r + 1] - source.row_ptr[r];
    if (r % 4 == 0)
      count = 0;
    if (r % 4 == 1)
      count = 1;
    for (int j = 0; j < count; ++j) {
      int p = source.row_ptr[r] + j;
      a.block_col.push_back(source.block_col[p]);
      a.values.insert(a.values.end(), source.values.begin() + source.value_off[p],
                      source.values.begin() + source.value_off[p + 1]);
      a.value_off.push_back(a.values.size());
    }
    a.row_ptr.push_back(int(a.block_col.size()));
  }
  a.validate();
  return a;
}

// Probe each method on the actual timed matrix, outside the measured region.
// Small correctness tests separately compare every output to a CPU reference.
void verify(const vbsr::HostMatrix& a, const std::vector<float>& b, const float* c, int rhs) {
  std::mt19937 rng(711);
  for (int trial = 0; trial < 64; ++trial) {
    int row = trial < 4 ? trial % a.block_rows : int(rng() % a.block_rows);
    int local_row = int(rng() % a.row_size[row]);
    int n = int(rng() % rhs);
    double expected = 0;
    for (int p = a.row_ptr[row]; p < a.row_ptr[row + 1]; ++p) {
      int col = a.block_col[p];
      for (int k = 0; k < a.col_size[col]; ++k) {
        expected += double(a.values[a.value_off[p] + local_row + k * a.row_size[row]]) *
                    b[a.col_scalar_off[col] + k + n * a.scalar_cols()];
      }
    }
    float actual;
    check(cudaMemcpy(&actual, c + a.row_scalar_off[row] + local_row + n * a.scalar_rows(),
                     sizeof(float), cudaMemcpyDeviceToHost));
    if (!std::isfinite(actual) || std::abs(actual - expected) > 5e-4) {
      throw std::runtime_error("audit CPU probe mismatch");
    }
  }
}

void measure(const std::string& name, const std::function<void(int)>& operation,
             const std::function<void()>& validate, int reps, int warmup, int position) {
  for (int i = 0; i < warmup; ++i)
    operation(i);
  check(cudaDeviceSynchronize());
  validate();
  cudaEvent_t begin, end;
  check(cudaEventCreate(&begin));
  check(cudaEventCreate(&end));
  for (int i = 0; i < reps; ++i) {
    auto start = std::chrono::steady_clock::now();
    check(cudaEventRecord(begin));
    operation(i);
    check(cudaEventRecord(end));
    check(cudaEventSynchronize(end));
    auto finish = std::chrono::steady_clock::now();
    float gpu;
    check(cudaEventElapsedTime(&gpu, begin, end));
    double host = std::chrono::duration<double, std::milli>(finish - start).count();
    if (!(gpu > 0) || !std::isfinite(gpu))
      throw std::runtime_error("invalid timing");
    std::cout << name << ',' << position << ',' << i << ',' << gpu << ',' << host << '\n';
  }
  check(cudaEventDestroy(begin));
  check(cudaEventDestroy(end));
}
} // namespace

int main(int argc, char** argv) {
  try {
    if (argc != 10)
      throw std::runtime_error(
          "usage: audit rows degree rhs distribution locality seed order_seed irregular reps");
    vbsr::GeneratorOptions options;
    options.block_rows = options.block_cols = std::stoi(argv[1]);
    options.degree = std::stoi(argv[2]);
    int rhs = std::stoi(argv[3]);
    std::string distribution = argv[4];
    if (distribution == "uniform")
      options.distribution = vbsr::Distribution::Uniform;
    else if (distribution == "low")
      options.distribution = vbsr::Distribution::LowVariance;
    else if (distribution == "high")
      options.distribution = vbsr::Distribution::HighVariance;
    else if (distribution == "bimodal")
      options.distribution = vbsr::Distribution::Bimodal;
    else
      throw std::runtime_error("invalid distribution");
    options.local_columns = std::string(argv[5]) == "local";
    options.seed = std::stoull(argv[6]);
    std::mt19937 order_rng(std::stoul(argv[7]));
    bool irregular = std::stoi(argv[8]) != 0;
    int reps = std::stoi(argv[9]);
    if (reps < 2)
      throw std::runtime_error("at least two repetitions required");
    auto a = vbsr::generate(options);
    if (irregular)
      a = thin_rows(a);
    vbsr::Matrix device(a);
    std::vector<float> b(a.scalar_cols() * rhs);
    std::mt19937 values_rng(9123);
    std::uniform_real_distribution<float> value(-1.f, 1.f);
    for (auto& x : b)
      x = value(values_rng);
    Buffer input(b.size()), input2(b.size()), output(a.scalar_rows() * rhs),
        output2(a.scalar_rows() * rhs);
    check(cudaMemcpy(input.data, b.data(), b.size() * sizeof(float), cudaMemcpyHostToDevice));
    check(cudaMemcpy(input2.data, b.data(), b.size() * sizeof(float), cudaMemcpyHostToDevice));
    cudaDeviceProp prop{};
    check(cudaGetDeviceProperties(&prop, 0));
    int driver, runtime;
    check(cudaDriverGetVersion(&driver));
    check(cudaRuntimeGetVersion(&runtime));
    std::cerr << "gpu=" << prop.name << ",cc=" << prop.major << '.' << prop.minor
              << ",driver_api=" << driver << ",runtime=" << runtime
              << ",scalar_rows=" << a.scalar_rows() << ",scalar_cols=" << a.scalar_cols()
              << ",blocks=" << a.block_col.size() << ",values=" << a.values.size() << '\n';
    std::vector<std::string> methods = {"direct",           "csr_default",    "csr_alg1_pre",
                                        "csr_alg2",         "csr_alg3_pre",   "grouped_cached",
                                        "grouped_changing", "direct_changing"};
    if (distribution == "uniform")
      methods.push_back("bsr32");
    std::shuffle(methods.begin(), methods.end(), order_rng);
    std::cout << std::setprecision(9) << "method,position,iteration,gpu_ms,host_ms\n";
    int position = 0;
    auto validate = [&] { verify(a, b, output.data, rhs); };
    for (const auto& method : methods) {
      if (method == "direct" || method == "direct_changing") {
        vbsr::Plan plan(device, {rhs, vbsr::Kernel::RowOwned});
        measure(
            method,
            [&](int i) {
              bool alt = method == "direct_changing" && i % 2;
              plan.execute(alt ? input2.data : input.data, alt ? output2.data : output.data);
            },
            validate, reps, 5, position);
      } else if (method.starts_with("grouped")) {
        vbsr::GroupedGemmPlan plan(a, rhs, true);
        measure(
            method,
            [&](int i) {
              bool alt = method == "grouped_changing" && i % 2;
              plan.execute(alt ? input2.data : input.data, alt ? output2.data : output.data);
            },
            [&] {
              validate();
              if (method == "grouped_changing")
                verify(a, b, output2.data, rhs);
            },
            reps, 5, position);
      } else {
        int alg = method == "csr_alg1_pre"   ? 1
                  : method == "csr_alg2"     ? 2
                  : method == "csr_alg3_pre" ? 3
                                             : 0;
        vbsr::ScalarCsrPlan plan(a, rhs, alg, alg == 1 || alg == 3, method == "bsr32");
        measure(
            method, [&](int) { plan.execute(input.data, output.data); }, validate, reps, 5,
            position);
      }
      ++position;
    }
    return 0;
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
