// Reuse the audited timing and probe helpers without duplicating their definitions.
#define main synthetic_audit_main
#include "audit.cpp"
#undef main
#include <cusparse.h>
#include <fstream>

namespace {
template <class T> std::vector<T> read_vector(std::ifstream& file) {
  uint64_t count;
  file.read(reinterpret_cast<char*>(&count), sizeof(count));
  if (!file || count > 100000000)
    throw std::runtime_error("invalid input vector");
  std::vector<T> values(count);
  file.read(reinterpret_cast<char*>(values.data()), count * sizeof(T));
  if (!file)
    throw std::runtime_error("truncated input vector");
  return values;
}
void sparse_check(cusparseStatus_t status) {
  if (status != CUSPARSE_STATUS_SUCCESS)
    throw std::runtime_error("compact CSR failure " + std::to_string(status));
}
struct CompactCsr {
  int *rows{}, *cols{};
  float* values{};
  void* workspace{};
  cusparseHandle_t handle{};
  cusparseSpMatDescr_t a{};
  cusparseDnMatDescr_t b{}, c{};
  cusparseSpMMAlg_t algorithm;
  CompactCsr(const std::vector<int>& row_ptr, const std::vector<int>& columns,
             const std::vector<float>& data, int64_t m, int64_t k, int rhs, float* input,
             float* output, int alg) {
    algorithm = alg == 1   ? CUSPARSE_SPMM_CSR_ALG1
                : alg == 2 ? CUSPARSE_SPMM_CSR_ALG2
                           : CUSPARSE_SPMM_CSR_ALG3;
    check(cudaMalloc(&rows, row_ptr.size() * sizeof(int)));
    check(cudaMalloc(&cols, columns.size() * sizeof(int)));
    check(cudaMalloc(&values, data.size() * sizeof(float)));
    check(cudaMemcpy(rows, row_ptr.data(), row_ptr.size() * sizeof(int), cudaMemcpyHostToDevice));
    check(cudaMemcpy(cols, columns.data(), columns.size() * sizeof(int), cudaMemcpyHostToDevice));
    check(cudaMemcpy(values, data.data(), data.size() * sizeof(float), cudaMemcpyHostToDevice));
    sparse_check(cusparseCreate(&handle));
    sparse_check(cusparseCreateCsr(&a, m, k, data.size(), rows, cols, values, CUSPARSE_INDEX_32I,
                                   CUSPARSE_INDEX_32I, CUSPARSE_INDEX_BASE_ZERO, CUDA_R_32F));
    sparse_check(cusparseCreateDnMat(&b, k, rhs, k, input, CUDA_R_32F, CUSPARSE_ORDER_COL));
    sparse_check(cusparseCreateDnMat(&c, m, rhs, m, output, CUDA_R_32F, CUSPARSE_ORDER_COL));
    float one = 1, zero = 0;
    size_t bytes;
    sparse_check(cusparseSpMM_bufferSize(handle, CUSPARSE_OPERATION_NON_TRANSPOSE,
                                         CUSPARSE_OPERATION_NON_TRANSPOSE, &one, a, b, &zero, c,
                                         CUDA_R_32F, algorithm, &bytes));
    if (bytes)
      check(cudaMalloc(&workspace, bytes));
    if (alg != 2)
      sparse_check(cusparseSpMM_preprocess(handle, CUSPARSE_OPERATION_NON_TRANSPOSE,
                                           CUSPARSE_OPERATION_NON_TRANSPOSE, &one, a, b, &zero, c,
                                           CUDA_R_32F, algorithm, workspace));
  }
  ~CompactCsr() {
    cudaFree(workspace);
    cusparseDestroyDnMat(b);
    cusparseDestroyDnMat(c);
    cusparseDestroySpMat(a);
    cusparseDestroy(handle);
    cudaFree(rows);
    cudaFree(cols);
    cudaFree(values);
  }
  void execute() {
    float one = 1, zero = 0;
    sparse_check(cusparseSpMM(handle, CUSPARSE_OPERATION_NON_TRANSPOSE,
                              CUSPARSE_OPERATION_NON_TRANSPOSE, &one, a, b, &zero, c, CUDA_R_32F,
                              algorithm, workspace));
  }
};
} // namespace

int main(int argc, char** argv) {
  try {
    if (argc != 5)
      throw std::runtime_error("usage: application input.bin rhs order_seed reps");
    int rhs = std::stoi(argv[2]), reps = std::stoi(argv[4]);
    std::ifstream file(argv[1], std::ios::binary);
    vbsr::HostMatrix a;
    a.row_size = read_vector<int>(file);
    a.col_size = read_vector<int>(file);
    a.block_rows = int(a.row_size.size());
    a.block_cols = int(a.col_size.size());
    a.row_scalar_off = read_vector<int64_t>(file);
    a.col_scalar_off = read_vector<int64_t>(file);
    a.row_ptr = read_vector<int>(file);
    a.block_col = read_vector<int>(file);
    a.value_off = read_vector<int64_t>(file);
    a.values = read_vector<float>(file);
    auto row_ptr = read_vector<int>(file), columns = read_vector<int>(file);
    auto values = read_vector<float>(file);
    a.validate();
    vbsr::Matrix device(a);
    cudaDeviceProp prop{};
    check(cudaGetDeviceProperties(&prop, 0));
    int driver, runtime;
    check(cudaDriverGetVersion(&driver));
    check(cudaRuntimeGetVersion(&runtime));
    std::cerr << "gpu=" << prop.name << ",cc=" << prop.major << '.' << prop.minor
              << ",driver_api=" << driver << ",runtime=" << runtime << '\n';
    std::vector<float> b(a.scalar_cols() * rhs);
    std::mt19937 value_rng(9123), order_rng(std::stoul(argv[3]));
    std::uniform_real_distribution<float> value(-1.f, 1.f);
    for (auto& x : b)
      x = value(value_rng);
    Buffer input(b.size()), output(a.scalar_rows() * rhs);
    check(cudaMemcpy(input.data, b.data(), b.size() * sizeof(float), cudaMemcpyHostToDevice));
    // Independent reference uses only source nonzeros, not packed block payloads.
    std::vector<float> reference(a.scalar_rows() * rhs);
    for (int n = 0; n < rhs; ++n) {
      for (int64_t r = 0; r < a.scalar_rows(); ++r) {
        double sum = 0;
        for (int p = row_ptr[r]; p < row_ptr[r + 1]; ++p)
          sum += double(values[p]) * b[columns[p] + n * a.scalar_cols()];
        reference[r + n * a.scalar_rows()] = float(sum);
      }
    }
    auto validate = [&] {
      std::vector<float> actual(reference.size());
      check(cudaMemcpy(actual.data(), output.data, actual.size() * sizeof(float),
                       cudaMemcpyDeviceToHost));
      double squared_error = 0, norm = 0;
      for (size_t i = 0; i < actual.size(); ++i) {
        double error = double(actual[i]) - reference[i];
        if (!std::isfinite(actual[i]) || std::abs(error) > 5e-4)
          throw std::runtime_error("application correctness failure");
        squared_error += error * error;
        norm += double(reference[i]) * reference[i];
      }
      if (std::sqrt(squared_error / (norm + 1e-30)) > 5e-5)
        throw std::runtime_error("application relative error failure");
    };
    std::vector<std::string> methods = {"direct", "compact_alg1_pre", "compact_alg2",
                                        "compact_alg3_pre", "grouped_cached"};
    std::shuffle(methods.begin(), methods.end(), order_rng);
    std::cout << std::setprecision(9) << "method,position,iteration,gpu_ms,host_ms\n";
    int position = 0;
    for (auto method : methods) {
      if (method == "direct") {
        vbsr::Plan plan(device, {rhs, vbsr::Kernel::RowOwned});
        measure(
            method, [&](int) { plan.execute(input.data, output.data); }, validate, reps, 5,
            position);
      } else if (method == "grouped_cached") {
        vbsr::GroupedGemmPlan plan(a, rhs, true);
        measure(
            method, [&](int) { plan.execute(input.data, output.data); }, validate, reps, 5,
            position);
      } else {
        int algorithm = method == "compact_alg1_pre" ? 1 : method == "compact_alg2" ? 2 : 3;
        CompactCsr plan(row_ptr, columns, values, a.scalar_rows(), a.scalar_cols(), rhs, input.data,
                        output.data, algorithm);
        measure(
            method, [&](int) { plan.execute(); }, validate, reps, 5, position);
      }
      ++position;
    }
    return 0;
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
