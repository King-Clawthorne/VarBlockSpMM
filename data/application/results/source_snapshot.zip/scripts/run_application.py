"""Run published-matrix checks serially after the synthetic GPU sweep."""
import csv
import argparse
import hashlib
import io
import itertools
import json
from pathlib import Path
import random
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=ROOT / 'data/application/results')
    args = parser.parse_args()
    output = args.output
    output.mkdir(parents=True, exist_ok=True)
    exe = ROOT / 'build/Release/vbsr_application_audit.exe'
    rng = random.Random(20260906)
    jobs = list(itertools.product((13, 14, 15), (8, 16, 32, 64), range(3)))
    rng.shuffle(jobs)
    source_paths = [ROOT / 'bench/application.cpp', ROOT / 'bench/audit.cpp',
                    ROOT / 'scripts/prepare_application.py', ROOT / 'scripts/run_application.py',
                    *ROOT.glob('src/**/*.cu'), *ROOT.glob('src/**/*.cpp'),
                    ROOT / 'include/varblockspmm/vbsr.hpp', ROOT / 'CMakeLists.txt']
    manifest = dict(reps=20, warmup=5, processes=3, jobs=jobs, randomization_seed=20260906,
                    executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
                    inputs={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in (ROOT / 'data/application').glob('*.bin')},
                    sources={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths})
    manifest_path = output / 'manifest.json'
    if manifest_path.exists() and json.loads(manifest_path.read_text()) != manifest:
        raise RuntimeError('Existing application results have different provenance')
    manifest_path.write_text(json.dumps(manifest, indent=2))
    for number, rhs, process in jobs:
        stem = f'bcsstk{number}_rhs{rhs}_p{process}'
        path = output / (stem + '.csv')
        order_seed = rng.randrange(2**31)
        if path.exists():
            continue
        command = [str(exe), str(ROOT / f'data/application/bcsstk{number}.bin'), str(rhs), str(order_seed), '20']
        result = subprocess.run(command, capture_output=True, text=True, timeout=180)
        (output / (stem + '.json')).write_text(json.dumps(dict(command=command, returncode=result.returncode,
            stderr=result.stderr, recorded_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())), indent=2))
        if result.returncode or len(list(csv.DictReader(io.StringIO(result.stdout)))) != 100:
            raise RuntimeError(result.stderr or 'Incomplete application measurements')
        path.write_text(result.stdout)
        print(stem, 'passed', flush=True)


if __name__ == '__main__':
    main()
