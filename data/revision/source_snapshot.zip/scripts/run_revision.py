"""Collect a serial GPU audit with randomized case and method order."""
import argparse
import csv
import hashlib
import io
import itertools
import json
from pathlib import Path
import random
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=ROOT / 'data/revision')
    parser.add_argument('--processes', type=int, default=3)
    parser.add_argument('--reps', type=int, default=20)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    exe = ROOT / 'build/Release/vbsr_audit.exe'
    cases = [(4096, degree, rhs, dist, locality, 1, 0)
             for dist, locality, degree, rhs in itertools.product(
                 ('uniform', 'low', 'high', 'bimodal'), ('local', 'random'), (2, 4, 8, 16), (8, 16, 32, 64))]
    for rows, dist, rhs, irregular in itertools.product((256, 1024, 4096), ('high', 'bimodal'), (8, 16, 32, 64), (0, 1)):
        case = (rows, 16, rhs, dist, 'random', 1, irregular)
        if case not in cases:
            cases.append(case)
    rng = random.Random(20260905)
    jobs = [(case, process) for case in cases for process in range(args.processes)]
    rng.shuffle(jobs)
    source_paths = [*ROOT.glob('src/**/*.cu'), *ROOT.glob('src/**/*.cpp'),
                    ROOT / 'bench/audit.cpp', ROOT / 'include/varblockspmm/vbsr.hpp',
                    ROOT / 'scripts/run_revision.py', ROOT / 'CMakeLists.txt']
    manifest = dict(started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                    cases=len(cases), processes=args.processes, reps=args.reps, warmup=5,
                    randomization_seed=20260905, matrix_seed=1, jobs=jobs,
                    executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
                    sources={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths})
    manifest_path = args.output / 'manifest.json'
    if manifest_path.exists():
        old = json.loads(manifest_path.read_text())
        if any(old[k] != manifest[k] for k in ('cases', 'processes', 'reps', 'executable_sha256', 'sources')):
            raise RuntimeError('Existing run differs from current configuration or executable')
    else:
        manifest_path.write_text(json.dumps(manifest, indent=2))
    start = time.monotonic()
    for index, (case, process) in enumerate(jobs):
        rows, degree, rhs, dist, locality, seed, irregular = case
        stem = f'{rows}_{degree}_{rhs}_{dist}_{locality}_s{seed}_i{irregular}_p{process}'
        path = args.output / (stem + '.csv')
        order_seed = rng.randrange(2**31)
        if path.exists():
            continue
        command = [str(exe), str(rows), str(degree), str(rhs), dist, locality,
                   str(seed), str(order_seed), str(irregular), str(args.reps)]
        result = subprocess.run(command, capture_output=True, text=True, timeout=180)
        (args.output / (stem + '.json')).write_text(json.dumps(dict(
            command=command, returncode=result.returncode, environment=result.stderr,
            recorded_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())), indent=2))
        if result.returncode:
            raise RuntimeError(result.stderr)
        data = list(csv.DictReader(io.StringIO(result.stdout)))
        expected = (9 if dist == 'uniform' else 8) * args.reps
        if len(data) != expected:
            raise RuntimeError(f'Incomplete output for {stem}')
        path.write_text(result.stdout)
        if index % 10 == 0 or index == len(jobs) - 1:
            print(f'{index + 1}/{len(jobs)} processes, {time.monotonic() - start:.0f}s elapsed', flush=True)
    print('Complete', flush=True)


if __name__ == '__main__':
    main()
