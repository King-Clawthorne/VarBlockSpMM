import subprocess,csv,io,json,statistics,math,itertools,pathlib
out=pathlib.Path('build/kernel-exploration'); out.mkdir(exist_ok=True)
results=[]
for degree,dist,loc in itertools.product([2,4,8,16],['uniform','low','high','bimodal'],['local','random']):
 p=subprocess.run(['build/kernel_experiment.exe','4096',str(degree),dist,loc,'1',str(len(results)+71)],capture_output=True,text=True,check=True)
 (out/f'{degree}_{dist}_{loc}.csv').write_text(p.stdout)
 med={v:statistics.median(float(r['gpu_ms']) for r in csv.DictReader(io.StringIO(p.stdout)) if r['method']==str(v)) for v in range(5)}
 results.append(dict(degree=degree,dist=dist,loc=loc,med=med))
for v in range(1,5):
 ratios=[r['med'][0]/r['med'][v] for r in results]
 print(v,'geo',math.exp(statistics.mean(map(math.log,ratios))),'min',min(ratios),'wins',sum(x>1 for x in ratios),flush=True)
(out/'summary.json').write_text(json.dumps(results,indent=2))
