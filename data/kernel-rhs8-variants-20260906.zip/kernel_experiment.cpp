#include "support.hpp"
#include <algorithm>
#include <iostream>
#include <random>
namespace vbsr { void launch_rhs8_candidate(DeviceMatrix, const float*, float*, int, cudaStream_t); }
int main(int argc, char** argv) { try {
 namespace b=vbsr::bench;
 vbsr::GeneratorOptions opts;
 opts.block_rows=opts.block_cols=std::stoi(argv[1]); opts.degree=std::stoi(argv[2]);
 opts.distribution=b::parse_distribution(argv[3]); opts.local_columns=b::parse_locality(argv[4]);
 opts.seed=std::stoull(argv[5]);
 auto host=vbsr::generate(opts); vbsr::Matrix matrix(host);
 auto input=b::make_input(host.scalar_cols()*8);
 b::DeviceBuffer<float> dinput(input.size()), output(host.scalar_rows()*8); dinput.upload(input);
 b::print_environment(&host); b::print_timing_header();
 std::vector<int> variants={0,1,2,3,4}; std::mt19937 rng(std::stoul(argv[6])); std::shuffle(variants.begin(),variants.end(),rng);
 int position=0;
 for(int variant:variants) b::measure(std::to_string(variant),[&](int){vbsr::launch_rhs8_candidate(matrix.device_view(),dinput.data(),output.data(),variant,0);},[&]{b::verify_probes(host,input,output.data(),8);},20,position++);
 } catch(const std::exception& e){std::cerr<<e.what();return 1;} }
