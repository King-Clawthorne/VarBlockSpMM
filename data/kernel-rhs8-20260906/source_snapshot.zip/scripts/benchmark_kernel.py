"""Serial RHS-8 release-versus-tiled validation with retained raw timings."""
import argparse
import csv
import hashlib
import io
import itertools
import json
import math
from pathlib import Path
import random
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reps', type=int, default=30)
    args = parser.parse_args()
    if args.reps < 2:
        parser.error('at least two repetitions required')
    args.output.mkdir(parents=True, exist_ok=False)
    executable = ROOT / 'build/Release/vbsr_kernel_audit.exe'
    cases = [(n, d, s, loc, 0) for n, d, s, loc in itertools.product(
        (256, 1024, 4096), (2, 4, 8, 16), ('uniform', 'low', 'high', 'bimodal'), ('local', 'random'))]
    cases += [(n, 16, s, loc, 1) for n, s, loc in itertools.product(
        (256, 1024, 4096), ('high', 'bimodal'), ('local', 'random'))]
    jobs = [(case, seed) for case in cases for seed in (1, 2, 3)]
    rng = random.Random(20260906)
    rng.shuffle(jobs)
    sources = [p for folder in ('src', 'include', 'bench') for p in (ROOT / folder).rglob('*') if p.is_file()]
    sources += [ROOT / 'CMakeLists.txt', Path(__file__).resolve()]
    manifest = dict(reps=args.reps, jobs=jobs,
                    executable_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),
                    sources={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (args.output / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    records = []
    for index, (case, seed) in enumerate(jobs):
        size, degree, distribution, locality, irregular = case
        command = [str(executable), str(size), str(degree), distribution, locality,
                   str(seed), str(rng.randrange(2**31)), str(irregular), str(args.reps)]
        run = subprocess.run(command, capture_output=True, text=True)
        stem = f'{size}_{degree}_{distribution}_{locality}_i{irregular}_s{seed}'
        (args.output / f'{stem}.csv').write_text(run.stdout)
        (args.output / f'{stem}.json').write_text(json.dumps(
            dict(command=command, returncode=run.returncode, environment=run.stderr), indent=2))
        run.check_returncode()
        rows = list(csv.DictReader(io.StringIO(run.stdout)))
        medians = {}
        for method in ('legacy', 'tiled'):
            selected = [r for r in rows if r['method'] == method]
            assert sorted(int(r['iteration']) for r in selected) == list(range(args.reps))
            times = [float(r['gpu_ms']) for r in selected]
            assert all(t > 0 and math.isfinite(t) for t in times)
            medians[method] = statistics.median(times)
        records.append(dict(case=case, seed=seed, **medians, ratio=medians['legacy']/medians['tiled']))
        if (index + 1) % 36 == 0:
            print(f'{index + 1}/{len(jobs)} processes passed', flush=True)
    geo = lambda values: math.exp(statistics.mean(map(math.log, values)))
    ratios = [geo(r['ratio'] for r in records if tuple(r['case']) == case) for case in cases]
    summary = dict(configurations=len(cases), processes=len(jobs),
                   geometric_speedup=geo(ratios), minimum=min(ratios), wins=sum(r > 1 for r in ratios),
                   by_size={size: geo(r['ratio'] for r in records if r['case'][0] == size) for size in (256, 1024, 4096)},
                   records=records)
    (args.output / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps({k: v for k, v in summary.items() if k != 'records'}, indent=2))


if __name__ == '__main__':
    main()
